create function diesel_set_updated_at() returns trigger
    language plpgsql
as
$$
BEGIN
    IF (
        NEW IS DISTINCT FROM OLD AND
        NEW.updated_at IS NOT DISTINCT FROM OLD.updated_at
    ) THEN
        NEW.updated_at := current_timestamp;
    END IF;
    RETURN NEW;
END;
$$;

alter function diesel_set_updated_at() owner to postgres;

